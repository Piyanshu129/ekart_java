# backend-ekart-aplication
Ekart application for both seller and customer using java
This ia an backend spring boot application for ekart application. It's for both seller and customer portal.
