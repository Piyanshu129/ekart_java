package com.infy.ekart.dto;

public enum CardType {
	DEBIT_CARD, CREDIT_CARD
}

